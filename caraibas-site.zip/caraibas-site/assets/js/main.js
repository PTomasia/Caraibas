const SITE_CONFIG = {
  whatsappNumber: '5500000000000',
  whatsappDefaultMessage: 'Olá! Vim pelo site da Caraíbas e quero entender como minha empresa pode começar a vender para o governo com segurança.'
};

const CURRENT_PAGE = document.body.dataset.page || '';

function initMobileMenu() {
  const toggle = document.querySelector('[data-menu-toggle]');
  const nav = document.querySelector('[data-nav]');
  if (!toggle || !nav) return;

  const closeMenu = () => {
    nav.classList.remove('open');
    document.body.classList.remove('no-scroll');
    toggle.setAttribute('aria-expanded', 'false');
  };

  toggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    document.body.classList.toggle('no-scroll', isOpen);
    toggle.setAttribute('aria-expanded', String(isOpen));
  });

  nav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', closeMenu);
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 860) closeMenu();
  });
}

function setActiveNav() {
  document.querySelectorAll('[data-page-link]').forEach((link) => {
    const page = link.getAttribute('data-page-link');
    if (page === CURRENT_PAGE) {
      link.setAttribute('aria-current', 'page');
    }
  });
}

function initReveal() {
  const items = document.querySelectorAll('.reveal');
  if (!items.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14 });

  items.forEach((item) => observer.observe(item));
}

function initFaq() {
  document.querySelectorAll('.faq-item').forEach((item, index) => {
    const btn = item.querySelector('.faq-question');
    if (!btn) return;

    const isOpen = item.classList.contains('active');
    btn.setAttribute('aria-expanded', String(isOpen));
    btn.addEventListener('click', () => {
      const open = item.classList.toggle('active');
      btn.setAttribute('aria-expanded', String(open));
    });

    if (index === 0 && !isOpen) {
      item.classList.add('active');
      btn.setAttribute('aria-expanded', 'true');
    }
  });
}

function buildWhatsAppUrl(message) {
  return `https://wa.me/${SITE_CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

function initWhatsAppButtons() {
  document.querySelectorAll('[data-wa]').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      const customMessage = btn.dataset.waMessage?.trim() || SITE_CONFIG.whatsappDefaultMessage;
      window.open(buildWhatsAppUrl(customMessage), '_blank', 'noopener');
    });
  });
}

function prefillServiceFromQuery() {
  const serviceInput = document.querySelector('#servico');
  const messageField = document.querySelector('#mensagem');
  if (!serviceInput && !messageField) return;

  const params = new URLSearchParams(window.location.search);
  const service = params.get('servico');
  if (!service) return;

  if (serviceInput) {
    const option = [...serviceInput.options].find((opt) => opt.value === service);
    if (option) serviceInput.value = service;
  }

  if (messageField && !messageField.value.trim()) {
    messageField.value = `Olá! Tenho interesse no serviço "${service}" e quero entender como a Caraíbas pode ajudar minha empresa a começar a vender para o governo.`;
  }
}

function initContactForm() {
  const form = document.querySelector('[data-contact-form]');
  const notice = document.querySelector('[data-form-feedback]');
  if (!form) return;

  const setFeedback = (message) => {
    if (!notice) return;
    notice.hidden = false;
    notice.textContent = message;
  };

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const name = form.querySelector('#nome')?.value.trim();
    const company = form.querySelector('#empresa')?.value.trim();
    const email = form.querySelector('#email')?.value.trim();
    const phone = form.querySelector('#telefone')?.value.trim();
    const service = form.querySelector('#servico')?.value.trim();
    const message = form.querySelector('#mensagem')?.value.trim();

    if (!name || !email || !message) {
      setFeedback('Preencha pelo menos nome, e-mail e mensagem para abrir o contato corretamente no WhatsApp.');
      return;
    }

    const lines = [
      'Olá! Vim pelo site da Caraíbas.',
      '',
      `Nome: ${name}`,
      company ? `Empresa: ${company}` : null,
      `E-mail: ${email}`,
      phone ? `Telefone: ${phone}` : null,
      service ? `Serviço de interesse: ${service}` : null,
      '',
      'Mensagem:',
      message
    ].filter(Boolean);

    window.open(buildWhatsAppUrl(lines.join('\n')), '_blank', 'noopener');
    setFeedback('Tudo certo. Abrimos o WhatsApp com sua mensagem preenchida.');
    form.reset();
  });
}

function setCurrentYear() {
  document.querySelectorAll('[data-current-year]').forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  setActiveNav();
  initReveal();
  initFaq();
  initWhatsAppButtons();
  prefillServiceFromQuery();
  initContactForm();
  setCurrentYear();
});
