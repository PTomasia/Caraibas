# Caraíbas — site institucional estático

Site institucional premium para **Caraíbas Consultoria em Licitação**, feito em **HTML/CSS/JS puro** para ser rápido, barato de manter e fácil de publicar na **Cloudflare Pages**.

## Estrutura

```bash
caraibas-site/
├── index.html
├── sobre.html
├── servicos.html
├── depoimentos.html
├── faq.html
├── contato.html
├── 404.html
├── robots.txt
├── sitemap.xml
├── site.webmanifest
├── assets/
│   ├── css/
│   │   └── styles.css
│   ├── js/
│   │   └── main.js
│   ├── img/
│   │   ├── favicon.svg
│   │   ├── logo-monograma.svg
│   │   └── og-cover.svg
│   └── icons/
│       └── whatsapp.svg
└── README.md
```

## Antes de publicar

### 1) Ajuste o número do WhatsApp

Abra o arquivo:

```bash
assets/js/main.js
```

Troque esta linha:

```js
whatsappNumber: '5500000000000',
```

Pelo seu número no formato internacional, sem `+`, espaços ou traços.

Exemplo:

```js
whatsappNumber: '5561999999999',
```

### 2) Ajuste domínio e SEO

Edite estes arquivos e substitua `SEU-DOMINIO.com` pelo domínio final:

- `robots.txt`
- `sitemap.xml`

Se quiser, também ajuste o conteúdo das metas Open Graph em cada HTML.

### 3) Substitua os depoimentos placeholder

A página `depoimentos.html` já está pronta visualmente, mas os textos foram deixados como **placeholders honestos** para você inserir depoimentos reais.

## Como rodar localmente no VS Code

### Opção A — extensão Live Server
A forma mais prática.

1. Abra a pasta `caraibas-site` no VS Code.
2. Instale a extensão **Live Server**.
3. Clique com o botão direito em `index.html`.
4. Clique em **Open with Live Server**.

O site vai abrir no navegador com atualização automática.

### Opção B — servidor local com Python
Se você tiver Python instalado:

```bash
cd caraibas-site
python -m http.server 5500
```

Depois abra:

```bash
http://localhost:5500
```

## Como publicar na Cloudflare Pages

Este projeto é estático, então você pode publicar de duas formas:

### Opção 1 — GitHub + deploy automático
Melhor para manutenção contínua.

1. Crie um repositório no GitHub.
2. Envie todos os arquivos do projeto para esse repositório.
3. No painel da Cloudflare, vá em **Workers & Pages**.
4. Clique em **Create application**.
5. Escolha **Pages**.
6. Clique em **Connect to Git**.
7. Conecte sua conta GitHub e selecione o repositório.
8. Em build settings, use:
   - **Framework preset:** None
   - **Build command:** deixe vazio
   - **Build output directory:** `/`
9. Salve e publique.

Como o site é estático, não precisa instalar dependências nem rodar build.

### Opção 2 — Direct Upload
Boa para publicar rápido sem Git.

1. No painel da Cloudflare, vá em **Workers & Pages**.
2. Clique em **Create application**.
3. Escolha **Pages**.
4. Selecione **Upload assets** / **Direct Upload**.
5. Envie a pasta do projeto ou os arquivos estáticos.
6. Publique.

## Formulário de contato

O formulário foi configurado para abrir o **WhatsApp com a mensagem já preenchida** com os dados do visitante.

Vantagens:
- não precisa backend
- custo zero
- reduz atrito
- mantém o foco em conversão para WhatsApp

## Personalizações recomendadas

Troque estes pontos antes da versão final:

- número do WhatsApp
- e-mail
- região de atendimento
- depoimentos reais
- logos de clientes, se existirem
- resultados / provas reais
- domínio final
- texto institucional final, caso queira deixar mais próximo da sua operação

## Observações

- O site já está responsivo e otimizado para celular.
- O visual segue a linha do brand book: sóbrio, elegante, técnico e premium.
- As animações são leves e não dependem de bibliotecas externas.
